/**
 * AFTERSHOCK AI — Multi-Page Client Controller
 * File: static/script.js
 *
 * 100% Offline Vanilla JavaScript.
 * Coordinates page detection, REST API communication, failure simulation,
 * interactive SVG network graph, and budget knapsack optimization.
 */

// =====================================================
// GLOBAL STATE & LAYOUT CONSTANTS
// =====================================================
const state = {
    currentScenario: "flood",
    currentBudget: 50000,
    infrastructure: null,
    scenarios: [],
    interventions: [],
    risks: null,

    // Active simulation & optimization results
    currentSimulation: null,
    baselineDisruption: null,
    recommendedPlan: null,

    selectedNodeId: "substation",
};

// Fixed SVG layout coordinates for the 8 municipal facilities in 940x380 viewBox
const NODE_COORDINATES = {
    substation: { x: 130, y: 110, name: "Electricity Substation", icon: "⚡" },
    road:       { x: 130, y: 280, name: "Main Access Road",       icon: "🛣️" },
    water:      { x: 370, y: 65,  name: "Water Pump Station",     icon: "💧" },
    tower:      { x: 370, y: 190, name: "Communication Tower",    icon: "📡" },
    emergency:  { x: 620, y: 280, name: "Emergency Control",      icon: "🚑" },
    treatment:  { x: 620, y: 65,  name: "Water Treatment",        icon: "🚰" },
    shelter:    { x: 820, y: 280, name: "Relief Shelter",         icon: "🏠" },
    hospital:   { x: 820, y: 155, name: "Hospital",               icon: "🏥" },
};


// =====================================================
// DOM INITIALIZATION & PAGE ROUTING
// =====================================================
document.addEventListener("DOMContentLoaded", async () => {
    checkBackendHealth();
    await loadSharedMetadata();

    // Route to active page handler safely
    initOverviewPage();
    initSimulationPage();
    initInfrastructurePage();
    initOptimizerPage();
    initRisksPage();
});


// =====================================================
// BACKEND HEALTH CHECK & SHARED METADATA
// =====================================================
async function checkBackendHealth() {
    const pill = document.getElementById("connectionPill");
    const text = document.getElementById("connectionText");
    if (!pill || !text) return;

    try {
        const res = await fetch("/api/status");
        if (res.ok) {
            const data = await res.json();
            pill.className = "status-pill online";
            text.textContent = `Backend: Online (${data.server || "Localhost"})`;
        } else {
            throw new Error(`HTTP ${res.status}`);
        }
    } catch (err) {
        pill.className = "status-pill offline";
        text.textContent = "Backend: Offline";
        console.warn("Backend health check failed:", err);
    }
}

async function loadSharedMetadata() {
    try {
        const [infraRes, scenRes, intervRes] = await Promise.all([
            fetch("/api/infrastructure").catch(() => null),
            fetch("/api/scenarios").catch(() => null),
            fetch("/api/interventions").catch(() => null),
        ]);

        if (infraRes && infraRes.ok) {
            state.infrastructure = await infraRes.json();
        }
        if (scenRes && scenRes.ok) {
            const scenData = await scenRes.json();
            state.scenarios = scenData.scenarios || [];
        }
        if (intervRes && intervRes.ok) {
            const intervData = await intervRes.json();
            state.interventions = intervData.interventions || [];
        }
    } catch (err) {
        console.error("Failed to load shared metadata:", err);
    }
}


// =====================================================
// PAGE 1: OVERVIEW PAGE HANDLER
// =====================================================
function initOverviewPage() {
    const previewSvg = document.getElementById("previewSvg");
    if (!previewSvg) return; // Not on overview page

    // Update summary counts from live metadata
    if (state.infrastructure) {
        const assetCountEl = document.getElementById("ovAssetCount");
        const depCountEl = document.getElementById("ovDepCount");
        if (assetCountEl) assetCountEl.textContent = state.infrastructure.total_assets || 8;
        if (depCountEl) depCountEl.textContent = state.infrastructure.dependencies?.length || 13;
    }
    if (state.scenarios) {
        const scenCountEl = document.getElementById("ovScenarioCount");
        if (scenCountEl) scenCountEl.textContent = state.scenarios.length || 3;
    }
    if (state.interventions) {
        const intervCountEl = document.getElementById("ovIntervCount");
        if (intervCountEl) intervCountEl.textContent = state.interventions.length || 6;
    }

    // Render preview SVG diagram
    renderNetworkSvg("previewSvg", { assets: state.infrastructure?.assets || [] });
}


// =====================================================
// PAGE 2: DISASTER SIMULATION HANDLER
// =====================================================
function initSimulationPage() {
    const btnRunSim = document.getElementById("btnRunSimulation");
    const selScenario = document.getElementById("simScenarioSelect");
    const btnReset = document.getElementById("btnResetSim");

    if (!btnRunSim || !selScenario) return; // Not on simulation page

    // Populate scenario dropdown
    if (state.scenarios.length > 0) {
        selScenario.innerHTML = "";
        state.scenarios.forEach(sc => {
            const opt = document.createElement("option");
            opt.value = sc.id;
            opt.textContent = sc.name;
            if (sc.id === state.currentScenario) opt.selected = true;
            selScenario.appendChild(opt);
        });
    }

    // Scenario change
    selScenario.addEventListener("change", (e) => {
        state.currentScenario = e.target.value;
        updateSimulationScenarioBrief();
        executeSimulation();
    });

    // Run Simulation Button Click
    btnRunSim.addEventListener("click", () => {
        executeSimulation();
    });

    // Reset button
    if (btnReset) {
        btnReset.addEventListener("click", () => {
            executeSimulation();
        });
    }

    updateSimulationScenarioBrief();
    executeSimulation();
}

function updateSimulationScenarioBrief() {
    const sc = state.scenarios.find(s => s.id === state.currentScenario);
    if (!sc) return;

    const tag = document.getElementById("briefHazardTag");
    const title = document.getElementById("briefScenarioTitle");
    const desc = document.getElementById("briefScenarioDesc");
    const inits = document.getElementById("briefInitialList");

    if (tag) tag.textContent = `HAZARD: ${(sc.hazard_type || sc.id).toUpperCase()}`;
    if (title) title.textContent = sc.name;
    if (desc) desc.textContent = sc.description;

    if (inits) {
        const names = (sc.initial_failures || []).map(id => NODE_COORDINATES[id]?.name || id);
        inits.textContent = names.join(", ") || "None";
    }
}

async function executeSimulation(protectedInterventions = []) {
    const btn = document.getElementById("btnRunSimulation");
    const spinner = document.getElementById("simSpinner");
    const btnText = document.getElementById("simBtnText");
    const banner = document.getElementById("simAlertBanner");

    // 1. Loading state
    if (btn) btn.disabled = true;
    if (spinner) spinner.style.display = "inline-block";
    if (btnText) btnText.textContent = "Simulating...";

    try {
        const payload = {
            scenario: state.currentScenario,
            protected_assets: protectedInterventions,
        };

        const res = await fetch("/api/simulate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || `Simulation failed with HTTP status ${res.status}`);
        }

        const data = await res.json();
        const sim = data.simulation || data;
        state.currentSimulation = sim;

        // 2. Update KPI Metrics
        const elScore = document.getElementById("kpiDisruptionScore");
        const elFailed = document.getElementById("kpiFailedCount");
        const elOper = document.getElementById("kpiOperCount");
        const elProt = document.getElementById("kpiProtCount");

        if (elScore) elScore.textContent = `${sim.disruption_score} pts`;
        if (elFailed) elFailed.textContent = `${sim.failed_count || 0} / ${sim.total_assets || 8}`;
        if (elOper) elOper.textContent = `${sim.operational_count || 0} / ${sim.total_assets || 8}`;
        if (elProt) elProt.textContent = `${sim.protected_count || 0}`;

        // 3. Render persistent SVG Network Graph
        renderNetworkSvg("simulationSvg", sim, "simInspIcon", "simInspName", "simInspBadge", "simInspMeta");

        // 4. Render Asset Status Table
        renderSimulationAssetTable(sim.assets || []);

        // 5. Render Cascade Timeline
        renderSimulationTimeline(sim.timeline || []);

        // 6. Show Success Banner
        if (banner) {
            banner.className = "alert-banner alert-success";
            banner.style.display = "flex";
            banner.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span><strong>Simulation Complete:</strong> Scenario <em>"${escapeHtml(sim.scenario_name)}"</em> produced a disruption score of <strong>${sim.disruption_score} points</strong> (${sim.failed_count} failed, ${sim.operational_count} operational).</span>
            `;
        }

    } catch (err) {
        console.error("Simulation execution error:", err);
        if (banner) {
            banner.className = "alert-banner alert-error";
            banner.style.display = "flex";
            banner.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><strong>Simulation Error:</strong> ${escapeHtml(err.message)}</span>
            `;
        }
    } finally {
        // Re-enable button
        if (btn) btn.disabled = false;
        if (spinner) spinner.style.display = "none";
        if (btnText) btnText.textContent = "Run Simulation";
    }
}

function renderSimulationAssetTable(assets) {
    const tbody = document.getElementById("simAssetTableBody");
    if (!tbody) return;

    let html = "";
    assets.forEach(a => {
        let pillClass = "pill-oper";
        let statusText = "Operational";

        if (a.status === "failed") {
            pillClass = "pill-fail";
            statusText = "Disrupted";
        } else if (a.status === "protected") {
            pillClass = "pill-prot";
            statusText = "Protected";
        }

        html += `
            <tr>
                <td><strong>${escapeHtml(a.icon || "🏢")} ${escapeHtml(a.name)}</strong></td>
                <td>${escapeHtml(a.category)}</td>
                <td><strong>${a.criticality}/10</strong></td>
                <td><span class="pill ${pillClass}">${statusText}</span></td>
                <td style="font-size: 0.72rem; color: var(--text-secondary);">${escapeHtml(a.backup_protection || "Standard")}</td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
}

function renderSimulationTimeline(events) {
    const container = document.getElementById("simTimelineList");
    const countBadge = document.getElementById("simTimelineCount");
    if (!container) return;

    if (!events || events.length === 0) {
        if (countBadge) countBadge.textContent = "0 Steps";
        container.innerHTML = `<div class="empty-timeline"><p>No cascade disruptions recorded in this scenario.</p></div>`;
        return;
    }

    if (countBadge) countBadge.textContent = `${events.length} Events`;
    let html = "";

    events.forEach(evt => {
        const isShock = evt.step === 0;
        const stepClass = isShock ? "event-shock" : "";
        const stepLabel = isShock ? "Initial Hazard Shock" : `Wave ${evt.step} Cascade`;

        html += `
            <div class="timeline-event ${stepClass}">
                <div class="event-title">[${stepLabel}] ${escapeHtml(evt.title)}</div>
                <div class="event-desc">${escapeHtml(evt.description)}</div>
            </div>
        `;
    });

    container.innerHTML = html;
}


// =====================================================
// PAGE 3: INFRASTRUCTURE NETWORK HANDLER
// =====================================================
function initInfrastructurePage() {
    const svg = document.getElementById("infrastructureSvg");
    if (!svg) return; // Not on infrastructure page

    // Render complete directed dependency SVG diagram
    renderNetworkSvg("infrastructureSvg", { assets: state.infrastructure?.assets || [] }, "infraInspIcon", "infraInspName", "infraInspBadge", "infraInspMeta");

    // Populate 8 asset specification cards
    const cardsGrid = document.getElementById("infraAssetCardsGrid");
    const catalogBadge = document.getElementById("catalogCountBadge");
    if (cardsGrid && state.infrastructure?.assets) {
        const assets = state.infrastructure.assets;
        if (catalogBadge) catalogBadge.textContent = `${assets.length} Facilities`;

        let html = "";
        assets.forEach(a => {
            const reqs = a.depends_on || [];
            const reqNames = reqs.map(r => NODE_COORDINATES[r]?.name || r).join(", ") || "None (Primary Source)";

            html += `
                <div class="asset-spec-card">
                    <div class="spec-top">
                        <span class="spec-name">${escapeHtml(a.icon || "🏢")} ${escapeHtml(a.name)}</span>
                        <span class="badge">${a.criticality}/10 Crit.</span>
                    </div>
                    <span class="spec-category">${escapeHtml(a.category)} &bull; ${escapeHtml(a.service || a.category)}</span>
                    <p class="spec-desc">${escapeHtml(a.description)}</p>
                    <div class="spec-deps"><strong>Prerequisites:</strong> ${escapeHtml(reqNames)}</div>
                </div>
            `;
        });
        cardsGrid.innerHTML = html;
    }

    // Populate directed dependencies list
    const depList = document.getElementById("infraDepList");
    const depBadge = document.getElementById("depCountBadge");
    if (depList && state.infrastructure?.dependencies) {
        const deps = state.infrastructure.dependencies;
        if (depBadge) depBadge.textContent = `${deps.length} Edges`;

        let html = "";
        deps.forEach((d, idx) => {
            const srcName = NODE_COORDINATES[d.source]?.name || d.source;
            const tgtName = NODE_COORDINATES[d.target]?.name || d.target;

            html += `
                <div class="dep-item">
                    <div class="dep-route">${idx + 1}. ${escapeHtml(srcName)} <span>&rarr;</span> ${escapeHtml(tgtName)}</div>
                    <span class="dep-desc">${escapeHtml(d.description || "Operational dependency")}</span>
                </div>
            `;
        });
        depList.innerHTML = html;
    }
}


// =====================================================
// PAGE 4: BUDGET OPTIMIZER HANDLER
// =====================================================
function initOptimizerPage() {
    const btnRunOpt = document.getElementById("btnRunOptimizer");
    const btnApply = document.getElementById("btnApplyOptimizerPlan");
    const selScenario = document.getElementById("optScenarioSelect");
    const inputBudget = document.getElementById("optBudgetInput");

    if (!btnRunOpt || !inputBudget) return; // Not on optimizer page

    // Populate scenario selector
    if (state.scenarios.length > 0 && selScenario) {
        selScenario.innerHTML = "";
        state.scenarios.forEach(sc => {
            const opt = document.createElement("option");
            opt.value = sc.id;
            opt.textContent = sc.name;
            if (sc.id === state.currentScenario) opt.selected = true;
            selScenario.appendChild(opt);
        });
    }

    // Scenario change
    selScenario.addEventListener("change", (e) => {
        state.currentScenario = e.target.value;
        state.recommendedPlan = null;
        if (btnApply) btnApply.disabled = true;
        clearOptimizerPlanUI();
        executeOptimizer();
    });

    // Budget input change
    inputBudget.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value);
        if (!isNaN(val) && val >= 0) {
            state.currentBudget = val;
            updateOptimizerChips(val);
        }
    });

    // Quick chips
    document.querySelectorAll(".chip").forEach(chip => {
        chip.addEventListener("click", () => {
            const val = parseFloat(chip.dataset.val);
            inputBudget.value = val;
            state.currentBudget = val;
            updateOptimizerChips(val);
        });
    });

    // Find Budget Plan
    btnRunOpt.addEventListener("click", () => {
        executeOptimizer();
    });

    // Apply Plan
    if (btnApply) {
        btnApply.addEventListener("click", () => {
            applyOptimizerPlan();
        });
    }

    executeOptimizer();
}

function updateOptimizerChips(amount) {
    document.querySelectorAll(".chip").forEach(chip => {
        if (parseFloat(chip.dataset.val) === amount) {
            chip.classList.add("active");
        } else {
            chip.classList.remove("active");
        }
    });
}

async function executeOptimizer() {
    const btn = document.getElementById("btnRunOptimizer");
    const btnText = document.getElementById("optBtnText");
    const btnApply = document.getElementById("btnApplyOptimizerPlan");
    const banner = document.getElementById("optAlertBanner");

    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = "Evaluating 64 Subsets...";

    try {
        const payload = {
            scenario: state.currentScenario,
            budget: state.currentBudget,
        };

        const res = await fetch("/api/optimize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || `Optimizer error HTTP ${res.status}`);
        }

        const data = await res.json();
        const plan = data.plan || data;
        state.recommendedPlan = plan;

        // Render KPI row
        const elBase = document.getElementById("optValBaseline");
        const elOpt = document.getElementById("optValOptimized");
        const elRed = document.getElementById("optValReduction");
        const elRedPct = document.getElementById("optValReductionPct");
        const elSpent = document.getElementById("optValSpent");
        const elLeft = document.getElementById("optValLeft");

        if (elBase) elBase.textContent = `${plan.baseline_disruption} pts`;
        if (elOpt) elOpt.textContent = `${plan.optimized_disruption} pts`;
        if (elRed) elRed.textContent = `${plan.disruption_reduction} pts`;
        if (elRedPct) elRedPct.textContent = `${plan.disruption_reduction_percent}% reduction`;
        if (elSpent) elSpent.textContent = `₹${Math.round(plan.total_cost).toLocaleString()}`;
        if (elLeft) elLeft.textContent = `Remaining: ₹${Math.round(plan.remaining_budget).toLocaleString()}`;

        // Render Plan Details
        renderOptimizerPlanUI(plan);

        // Render Stable Comparison Chart
        renderOptimizerComparisonChart(plan.baseline_disruption, plan.optimized_disruption, plan.disruption_reduction_percent);

        // Render Asset Status Post-Plan
        if (plan.optimized_simulation?.assets) {
            renderOptimizerAssetTable(plan.optimized_simulation.assets);
        }

        // Enable Apply Plan button if interventions were recommended
        if (btnApply) {
            btnApply.disabled = !(plan.selected_interventions && plan.selected_interventions.length > 0);
        }

        // Show notice in banner
        if (banner) {
            banner.className = "alert-banner alert-success";
            banner.style.display = "flex";
            banner.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span><strong>Optimal Plan Identified:</strong> Evaluated ${plan.combinations_evaluated || 64} combinations. Saved <strong>${plan.disruption_reduction} points (${plan.disruption_reduction_percent}%)</strong> using ₹${Math.round(plan.total_cost).toLocaleString()}.</span>
            `;
        }

    } catch (err) {
        console.error("Optimizer error:", err);
        if (banner) {
            banner.className = "alert-banner alert-error";
            banner.style.display = "flex";
            banner.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><strong>Optimization Error:</strong> ${escapeHtml(err.message)}</span>
            `;
        }
    } finally {
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = "Find Budget Plan";
    }
}

async function applyOptimizerPlan() {
    if (!state.recommendedPlan) return;

    const btn = document.getElementById("btnApplyOptimizerPlan");
    const applyText = document.getElementById("applyBtnText");
    const banner = document.getElementById("optAlertBanner");

    if (btn) btn.disabled = true;
    if (applyText) applyText.textContent = "Applying...";

    try {
        const selectedIds = state.recommendedPlan.selected_intervention_ids || [];

        const payload = {
            scenario: state.currentScenario,
            protected_assets: selectedIds,
        };

        const res = await fetch("/api/simulate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || `HTTP ${res.status}`);
        }

        const data = await res.json();
        const sim = data.simulation || data;

        // Update protected asset table from the real simulation response
        if (sim.assets) {
            renderOptimizerAssetTable(sim.assets);
        }

        // Keep comparison chart persistent and accurate
        renderOptimizerComparisonChart(
            state.recommendedPlan.baseline_disruption,
            sim.disruption_score,
            state.recommendedPlan.disruption_reduction_percent
        );

        const lblState = document.getElementById("optLblSimState");
        if (lblState) lblState.textContent = "Plan Active in Simulation";

        if (applyText) applyText.textContent = "Plan Active";
        if (btn) btn.disabled = false;

        if (banner) {
            banner.className = "alert-banner alert-success";
            banner.style.display = "flex";
            banner.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span><strong>Plan Applied to Live Simulation:</strong> Disruption score is now confirmed at <strong>${sim.disruption_score} points</strong>.</span>
            `;
        }

    } catch (err) {
        console.error("Apply Plan error:", err);
        alert(`Apply Plan Error: ${err.message}`);
        if (applyText) applyText.textContent = "Apply Plan";
        if (btn) btn.disabled = false;
    }
}

function renderOptimizerPlanUI(plan) {
    const container = document.getElementById("optPlanBody");
    const badge = document.getElementById("optCombBadge");

    if (badge) badge.textContent = `${plan.combinations_evaluated || 64} affordable evaluated`;
    if (!container) return;

    let html = `
        <div class="plan-summary-msg">
            ${escapeHtml(plan.explanation)}
        </div>
    `;

    if (plan.selected_interventions && plan.selected_interventions.length > 0) {
        html += `<div class="plan-list">`;
        plan.selected_interventions.forEach(item => {
            html += `
                <div class="plan-row">
                    <div>
                        <div class="plan-row-name">${escapeHtml(item.name)}</div>
                        <div class="plan-row-desc">${escapeHtml(item.description)}</div>
                    </div>
                    <div class="plan-row-cost">₹${item.cost.toLocaleString()}</div>
                </div>
            `;
        });
        html += `</div>`;
    } else {
        html += `
            <div class="empty-plan-box">
                <p>No interventions allocated within this budget.</p>
                <span>Increase the budget or select another hazard scenario to evaluate measures.</span>
            </div>
        `;
    }

    container.innerHTML = html;
}

function clearOptimizerPlanUI() {
    const container = document.getElementById("optPlanBody");
    if (!container) return;
    container.innerHTML = `
        <div class="empty-plan-box">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            <p>No intervention plan generated yet.</p>
            <span>Enter your budget in Indian Rupees (₹) and click <strong>"Find Budget Plan"</strong>.</span>
        </div>
    `;
}

function renderOptimizerComparisonChart(beforeScore, afterScore, reductionPct) {
    const valBefore = document.getElementById("optBarValBefore");
    const valAfter = document.getElementById("optBarValAfter");
    const barBefore = document.getElementById("optBarBefore");
    const barAfter = document.getElementById("optBarAfter");
    const summary = document.getElementById("optChartSummary");

    if (valBefore) valBefore.textContent = beforeScore !== null ? `${beforeScore} pts` : "--";

    const maxVal = Math.max(65, beforeScore || 1);
    const beforeHeight = beforeScore !== null ? Math.min(100, Math.max(8, (beforeScore / maxVal) * 100)) : 0;
    if (barBefore) barBefore.style.height = `${beforeHeight}%`;

    if (afterScore === null || afterScore === undefined) {
        if (valAfter) valAfter.textContent = "--";
        if (barAfter) barAfter.style.height = "4%";
        if (summary) summary.textContent = `Baseline disruption score is ${beforeScore} points.`;
    } else {
        if (valAfter) valAfter.textContent = `${afterScore} pts`;

        // GUARANTEED VISIBLE PEDESTAL: even if disruption is 0 (100% saved), keep a 6% minimum pedestal
        const afterHeight = afterScore > 0 ? Math.min(100, Math.max(8, (afterScore / maxVal) * 100)) : 6;
        if (barAfter) barAfter.style.height = `${afterHeight}%`;

        const saved = (beforeScore || 0) - afterScore;
        const pctStr = reductionPct !== null && reductionPct !== undefined ? reductionPct : (beforeScore > 0 ? ((saved / beforeScore) * 100).toFixed(1) : 0);

        if (summary) {
            if (saved > 0) {
                summary.innerHTML = `<strong>Resilience Gain:</strong> Disruption reduced from <strong>${beforeScore}</strong> to <strong>${afterScore}</strong> (${saved} points saved, <strong>${pctStr}% improvement</strong>).`;
            } else if (beforeScore === 0) {
                summary.textContent = "Scenario causes zero baseline disruption. No intervention needed.";
            } else {
                summary.textContent = "No disruption score reduction achieved within the selected budget limit.";
            }
        }
    }
}

function renderOptimizerAssetTable(assets) {
    const tbody = document.getElementById("optAssetTableBody");
    if (!tbody) return;

    let html = "";
    assets.forEach(a => {
        let pillClass = "pill-oper";
        let statusText = "Operational";

        if (a.status === "failed") {
            pillClass = "pill-fail";
            statusText = "Disrupted";
        } else if (a.status === "protected") {
            pillClass = "pill-prot";
            statusText = "Protected";
        }

        html += `
            <tr>
                <td><strong>${escapeHtml(a.icon || "🏢")} ${escapeHtml(a.name)}</strong></td>
                <td>${escapeHtml(a.category)}</td>
                <td><strong>${a.criticality}/10</strong></td>
                <td><span class="pill ${pillClass}">${statusText}</span></td>
                <td style="font-size: 0.72rem; color: var(--text-secondary);">${escapeHtml(a.backup_protection || "Standard")}</td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
}


// =====================================================
// PAGE 5: AI RISK ANALYSIS HANDLER
// =====================================================
async function initRisksPage() {
    const grid = document.getElementById("pageRisksGrid");
    if (!grid) return; // Not on risks page

    try {
        const res = await fetch("/api/risks");
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();
        state.risks = data;

        const badge = document.getElementById("riskAssetCountBadge");
        if (badge) badge.textContent = `${data.assets?.length || 8} Facilities Evaluated`;

        let html = "";
        (data.assets || []).forEach(item => {
            let badgeClass = "ml-badge-medium";
            if (item.risk_label.includes("Low")) badgeClass = "ml-badge-low";
            if (item.risk_label.includes("High")) badgeClass = "ml-badge-high";

            const feats = item.features || {};

            html += `
                <div class="ml-card">
                    <div class="ml-card-top">
                        <div>
                            <div class="ml-facility-name">${escapeHtml(item.asset_name)}</div>
                            <div class="ml-facility-cat">${escapeHtml(item.category)}</div>
                        </div>
                        <span class="ml-risk-badge ${badgeClass}">${escapeHtml(item.risk_label)}</span>
                    </div>
                    <div class="ml-features-row">
                        <div>Criticality: <strong>${feats.criticality || "--"}/10</strong></div>
                        <div>Exposure Score: <strong>${feats.exposure_score || "--"}/10</strong></div>
                        <div>Prerequisites: <strong>${feats.dependency_count ?? "--"}</strong></div>
                        <div>Redundancy Tier: <strong>${feats.redundancy_level ?? "--"}</strong></div>
                    </div>
                    <div style="font-size: 0.72rem; color: var(--text-muted); display: flex; justify-content: space-between;">
                        <span>Model Confidence:</span>
                        <strong style="color: var(--text-primary);">${Math.round((item.confidence_score || 0) * 100)}%</strong>
                    </div>
                </div>
            `;
        });

        grid.innerHTML = html;

    } catch (err) {
        console.error("AI Risks loading error:", err);
        grid.innerHTML = `<div class="empty-plan-box"><p>Failed to load AI risk predictions from backend.</p></div>`;
    }
}


// =====================================================
// PERSISTENT SVG NETWORK GRAPH RENDERER
// (USED ACROSS SIMULATION, INFRASTRUCTURE, & OVERVIEW)
// =====================================================
function renderNetworkSvg(svgId, sim, iconId, nameId, badgeId, metaId) {
    const svg = document.getElementById(svgId);
    if (!svg) return;

    // Build map of current statuses
    const assetMap = {};
    if (sim && sim.assets) {
        sim.assets.forEach(a => {
            assetMap[a.id] = a;
        });
    }

    const deps = state.infrastructure?.dependencies || [
        { source: "substation", target: "water" },
        { source: "substation", target: "tower" },
        { source: "substation", target: "hospital" },
        { source: "water", target: "hospital" },
        { source: "tower", target: "hospital" },
        { source: "road", target: "hospital" },
        { source: "substation", target: "emergency" },
        { source: "tower", target: "emergency" },
        { source: "road", target: "emergency" },
        { source: "water", target: "shelter" },
        { source: "road", target: "shelter" },
        { source: "substation", target: "treatment" },
        { source: "water", target: "treatment" },
    ];

    // Clear inner SVG elements safely
    svg.innerHTML = "";

    // 1. Arrowhead defs
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    defs.innerHTML = `
        <marker id="${svgId}-arrow-oper" viewBox="0 0 10 10" refX="28" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 10 5 L 0 9 z" fill="#2c3c5a" />
        </marker>
        <marker id="${svgId}-arrow-fail" viewBox="0 0 10 10" refX="28" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 10 5 L 0 9 z" fill="#ef4444" />
        </marker>
    `;
    svg.appendChild(defs);

    // 2. Render directed dependency edges
    deps.forEach(dep => {
        const srcPos = NODE_COORDINATES[dep.source];
        const tgtPos = NODE_COORDINATES[dep.target];
        if (!srcPos || !tgtPos) return;

        const isSourceFailed = assetMap[dep.source]?.status === "failed";
        const edgeClass = isSourceFailed ? "svg-edge edge-fail" : "svg-edge edge-oper";
        const marker = isSourceFailed ? `url(#${svgId}-arrow-fail)` : `url(#${svgId}-arrow-oper)`;

        const dx = tgtPos.x - srcPos.x;
        const cx1 = srcPos.x + dx * 0.45;
        const cy1 = srcPos.y;
        const cx2 = srcPos.x + dx * 0.55;
        const cy2 = tgtPos.y;

        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        path.setAttribute("d", `M ${srcPos.x} ${srcPos.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${tgtPos.x} ${tgtPos.y}`);
        path.setAttribute("class", edgeClass);
        path.setAttribute("marker-end", marker);
        svg.appendChild(path);
    });

    // 3. Render asset nodes
    Object.keys(NODE_COORDINATES).forEach(id => {
        const coord = NODE_COORDINATES[id];
        const aInfo = assetMap[id] || { status: "operational", criticality: 8 };

        const nodeG = document.createElementNS("http://www.w3.org/2000/svg", "g");
        nodeG.setAttribute("class", `svg-node node-${aInfo.status}`);
        nodeG.setAttribute("transform", `translate(${coord.x}, ${coord.y})`);

        // Node Card Box
        const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rect.setAttribute("class", "svg-node-box");
        rect.setAttribute("x", "-65");
        rect.setAttribute("y", "-22");
        rect.setAttribute("width", "130");
        rect.setAttribute("height", "44");
        rect.setAttribute("rx", "6");

        // Icon
        const icon = document.createElementNS("http://www.w3.org/2000/svg", "text");
        icon.setAttribute("class", "svg-node-icon");
        icon.setAttribute("x", "-46");
        icon.setAttribute("y", "5");
        icon.textContent = coord.icon;

        // Name
        const name = document.createElementNS("http://www.w3.org/2000/svg", "text");
        name.setAttribute("class", "svg-node-name");
        name.setAttribute("x", "8");
        name.setAttribute("y", "-3");
        name.textContent = coord.name.length > 14 ? coord.name.substring(0, 13) + "…" : coord.name;

        // Status
        const stat = document.createElementNS("http://www.w3.org/2000/svg", "text");
        stat.setAttribute("class", "svg-node-stat");
        stat.setAttribute("x", "8");
        stat.setAttribute("y", "12");
        stat.textContent = `${aInfo.status.toUpperCase()} (${aInfo.criticality || 8}/10)`;

        nodeG.appendChild(rect);
        nodeG.appendChild(icon);
        nodeG.appendChild(name);
        nodeG.appendChild(stat);

        // Click to inspect
        if (iconId && nameId) {
            nodeG.addEventListener("click", () => {
                inspectFacilityNode(id, aInfo, iconId, nameId, badgeId, metaId);
            });
        }

        svg.appendChild(nodeG);
    });

    // Inspect initial node if inspector elements exist
    if (iconId && nameId && assetMap[state.selectedNodeId]) {
        inspectFacilityNode(state.selectedNodeId, assetMap[state.selectedNodeId], iconId, nameId, badgeId, metaId);
    }
}

function inspectFacilityNode(id, assetInfo, iconId, nameId, badgeId, metaId) {
    state.selectedNodeId = id;
    const coord = NODE_COORDINATES[id] || {};
    const iconEl = document.getElementById(iconId);
    const nameEl = document.getElementById(nameId);
    const badgeEl = document.getElementById(badgeId);
    const metaEl = document.getElementById(metaId);

    if (iconEl) iconEl.textContent = coord.icon || "🏢";
    if (nameEl) nameEl.textContent = assetInfo.name || coord.name;

    if (badgeEl) {
        badgeEl.textContent = (assetInfo.status || "Operational").toUpperCase();
        if (assetInfo.status === "failed") {
            badgeEl.style.background = "rgba(239, 68, 68, 0.15)";
            badgeEl.style.color = "#f87171";
        } else if (assetInfo.status === "protected") {
            badgeEl.style.background = "rgba(6, 182, 212, 0.15)";
            badgeEl.style.color = "#38bdf8";
        } else {
            badgeEl.style.background = "rgba(16, 185, 129, 0.15)";
            badgeEl.style.color = "#34d399";
        }
    }

    if (metaEl) {
        const rawAsset = state.infrastructure?.assets?.find(a => a.id === id);
        const category = rawAsset?.category || assetInfo.category || "Municipal";
        const criticality = assetInfo.criticality || rawAsset?.criticality || 8;
        const reqs = rawAsset?.depends_on || [];
        const reqStr = reqs.length > 0
            ? reqs.map(r => NODE_COORDINATES[r]?.name || r).join(", ")
            : "Primary Source (No Prerequisites)";

        metaEl.innerHTML = `${category} &bull; Criticality: <strong>${criticality}/10</strong> &bull; Prerequisites: <strong>${escapeHtml(reqStr)}</strong>`;
    }
}


// =====================================================
// UTILITY SANITIZATION
// =====================================================
function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
